#include"K58Menu.h"
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string> 
#include <iomanip>
using namespace std;

class Menu :public K58Menu 
{
public:
	Menu(): K58Menu(){};
	void AddItem();
	void ShowListItems();
	void HideItem();
	void ShowItem();
	bool SearchItem();
};

class Sach
{
private:
	string TenSach;
	string TacGia;
	string NhaXuatBan;
	string TrangThai; //2 trang thai: chua cho muon || da cho muon
public:
	void setTenSach(string TS);
	string getTenSach();
	void setTacGia(string TG);
	string getTacGia();
	void setNhaXuatBan(string NXB);
	string getNhaXuatBan();
	void setTrangThai(string TT);
	string getTrangThai();
	Sach();
	Sach(string TS, string TG, string NXB, string TT);
	void ChuyenTrangThai();
	void NhapSach();
	void XuatSach();
};

//DN ham;
Sach::Sach()
{
	TenSach = " ";
	TacGia = " ";
	NhaXuatBan = " ";
	TrangThai = " ";   
}
Sach::Sach(string TS, string TG, string NXB, string TT)
{
	TenSach = TS;
	TacGia = TG;
	NhaXuatBan = NXB;
	TrangThai = TT;
}

void Sach::setTenSach(string TS)
{
	TenSach = TS;
}
string Sach::getTenSach()
{
	return TenSach;
}
void Sach::setTacGia(string TG)
{
	TacGia = TG;
}
string Sach::getTacGia()
{
	return TacGia;
}
void Sach::setNhaXuatBan(string NXB)
{
	NhaXuatBan = NXB;
}
string Sach::getNhaXuatBan()
{
	return NhaXuatBan;
}
void Sach::setTrangThai(string TT)
{
	TrangThai = TT;
}
string Sach::getTrangThai()
{
	return TrangThai;
}

void Sach::NhapSach()
{
	cin.ignore();
	cout << "\nMoi nhap ten sach: ";
	getline(cin, TenSach);
	cout << "\nMoi nhap tac gia: ";
	getline(cin, TacGia);
	cout << "\nMoi nhap nha xuat ban: ";
	getline(cin, NhaXuatBan);
	cout << "\nMoi nhap trang thai sach: ";
	getline(cin, TrangThai);
}

void Sach::ChuyenTrangThai()
{
	cin.ignore();
	cout << "Moi nhap lai trang thai sach: ";
	getline(cin, TrangThai);
}

void Sach::XuatSach()
{
	cout << setw(10) << TenSach << setw(20) << TacGia << setw(20) << NhaXuatBan << setw(20) << TrangThai << endl;
}


// Menu chuong trinh
void K58Menu::ShowMenu()
{
	while (1)
	{
		cout << "\r\nMenu quan ly thu vien:\r\n1.Them sach\
                                    \r\n2.Hien danh sach sach co the muon\
                                    \r\n3.Cho muon sach\
                                    \r\n4.Tra sach\
                                    \r\n5.Tim kiem theo ten sach\
                                    \r\n6.Ket thuc\r\nChon: ";
		int m_selected;
		cin >> m_selected;
		system("cls");		// thay cho ham clrscr()
		switch (m_selected)
		{
		case 1: AddItem();                
			_getch();					  
			break;
		case 2: ShowListItems();
			_getch();
			break;
		case 3: HideItem();
			_getch();
			break;
		case 4: ShowItem();
			_getch();
			break;
		case 5: SearchItem();
			_getch();
			break;
		case 6: exit(0);
			break;
		default:
			cout << "Hay nhap lai:\r\n";
		}
	}
}

Sach S[100];
int index = 0; 
bool KiemtraSach(string TenSach, int &vt)
{
	bool kt = false;       //Sach khong ton tai
	for (int i = 0; i < index; i++)
		if (TenSach == S[i].getTenSach())
		{
			vt = i;
			kt = true;     //Sach ton tai
			break;
		}
	return kt;
}

void Menu::AddItem()
{
	cout << "AddItem()"<<endl;
	int SoSachThem;
	cout << "Moi nhap so sach can them: ";
	cin >> SoSachThem;
	for (int i = 0; i < SoSachThem; i++)
	{
		Sach tmpS;
		tmpS.NhapSach();
		S[index] = tmpS;
		index++;
	}
}

void Menu::ShowListItems()
{
	cout << "ShowListItems()"<<endl; 
	cout << setw(10) << "Ten Sach" << setw(20) << "Tac Gia" << setw(20) << "Nha Xuat Ban" << setw(20) << "Trang Thai" << endl;
	for (int i = 0; i < index; i++)
		if (S[i].getTrangThai() == "chua cho muon")
		{
			S[i].XuatSach();
		}
}

void Menu::HideItem()
{
	cout << "HideItem()" << endl;
	string MuonSach;
	for (int vt = 0; vt < index; vt++)
	{
		cin.ignore();
		cout << "Moi nhap ten sach can muon: ";
		getline(cin, MuonSach);
		bool kts;
		kts = KiemtraSach(MuonSach, vt);
		if ((kts) && (S[vt].getTrangThai() == "chua cho muon"))
		{
			S[vt].ChuyenTrangThai();
			cout << "Muon sach " << MuonSach << " thanh cong!" << endl;
		}
		else
		{
			cout << "Ten sach khong chinh xac hoac sach da cho muon." << endl;
		}
		break;
	}
}

void Menu::ShowItem()
{
	cout << "ShowItem()"<<endl;
	string TraSach;
	for (int vt = 0; vt < index; vt++)
	{
		cin.ignore();
		cout << "Moi nhap ten sach can tra: ";
		getline(cin, TraSach);
		bool kts;
		kts = KiemtraSach(TraSach, vt);
		if ((kts) && (S[vt].getTrangThai() == "da cho muon"))
		{
			S[vt].ChuyenTrangThai();
			cout << "Tra sach " << TraSach << " thanh cong!";			
		}
		else
			cout << "Ten sach khong chinh xac hoac ban khong muon sach nay!" << endl;
		break;
	}
}

bool Menu::SearchItem() 
{
	cout << "SearchItem()"<<endl;
	string TimSach;
	cin.ignore();
	cout << "Moi nhap ten sach can tim: ";
	getline(cin, TimSach);
	bool kt;
	int vt;
	kt = KiemtraSach(TimSach, vt);
	if (kt)
	{
		cout << "Da tim thay thong tin sach: " << endl;
		cout << setw(10) << "Ten Sach" << setw(20) << "Tac Gia" << setw(20) << "Nha Xuat Ban" << setw(20) << "Trang Thai" << endl;
		S[vt].XuatSach();
	}
	else
		cout << "Khong tim thay thong tin sach" << endl;
	return 0;
}

void main()
{
	Menu menu;
	menu.ShowMenu();
}