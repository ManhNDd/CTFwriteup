#include <iostream>
#include <stdio.h> 
#include <string>
#include <map>
#include <algorithm>
#include <string.h>
#include <vector>
#include <fstream>
using namespace std;

bool words(pair<int, string> w1, pair<int, string> w2)
{
	if (w1.first != w2.first)
		return w1.first > w2.first;
	return w1.second < w2.second;
}

int main()
{
	char s[20000];
	int ngay = 0, N;
	map<string, int> D[7], Top;
	
	while (scanf("%s", s) == 1)
	{
		if (!strcmp(s, "<text>"))
		{
			ngay = (ngay + 1) % 7;
			for (map<string, int>::iterator ite = D[ngay].begin(); ite != D[ngay].end(); ite++)
				Top[ite->first] -= ite->second;
			D[ngay].clear();
			while (scanf("%s", s) == 1)
			{
				if (!strcmp(s, "</text>"))
					break;
				if (strlen(s) < 4)
					continue;
				D[ngay][s]++, Top[s]++;
			}
		}
		else if (!strcmp(s, "<top"))
		{
			scanf("%d %*s", &N);
			vector< pair<int, string> > A;
			for (map<string, int>::iterator ite = Top.begin(); ite != Top.end(); ite++)
				if (ite->second > 0)
					A.push_back(make_pair(ite->second, ite->first));
			sort(A.begin(), A.end(), words);
			int M = 0;
			printf("<top %d>\n", N);

			for (int i = 0; i < A.size(); i++)
			{
				printf("%s %d\n", A[i].second.c_str(), A[i].first);
				M++;
				if (i + 1 < A.size() && A[i].first > A[i + 1].first)
				{
					if (M >= N)
						break;
				}
			}
			printf("</top>\n");
		}
	}
	
	return 0;
}